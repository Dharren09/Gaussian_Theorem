from setuptools import setup

setup(name="Gaussian_Theorem",
      version="1.0",
      description="Gaussian and Binomial distributions", 
      packages=['Gaussian_Theorem'],
      author = 'Makoha Dharren Pius',
      author_email = 'dharrenpius@outlook.com',
    zip_safe=False)